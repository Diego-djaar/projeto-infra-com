# Parte 2

A segunda parte do projeto consiste em fazer um chat básico com transferência confiável, segundo o canal de transmissão confiável rdt3.0,

O cliente é o programa client1.py e o servidor é o programa server1.py. Ambos utilizam as funções definidas em RDTs.py.

O chat funciona para mais de um cliente simultâneamente. No entanto, as mensagens do chat público apenas são exibidas no terminal do servidor.

São implementadas as funcionalidade de Conectar à sala, Sair da sala e Exibir lista de usuários do chat
